#include"easyx.h"
void data_tansform(char data[], int len)
{
    data[len] = '\0'; // �����ַ�����ֹ��
    char data_a[14] = { 0 };
    int n;
    for (int i = 0;i < 14;i++)//���������ӡ
    {
        if ((data[i] & 0xFF) == 0x0) { n = 0; }
        else if ((data[i] & 0xFF) == 0x1c) { n = 1; }
        else if ((data[i] & 0xFF) == 0xe0) { n = 2; }
        else if ((data[i] & 0xFF) == 0xfc) { n = 3; }
        data_a[i] = n;
    }
    //��������
    n = 0;
    int k = 1;
    for (int i = 0;i <= 7;i++)
    {
        n += data_a[7 - i] * k;
        k *= 4;
    }
    float f = n;
    f = f / 11.0;
    //ͼ�ν������
    clearDevice();
    title();
    distance(f, data_a[13]);
    led(data_a[8], data_a[9], data_a[10], data_a[11]);
    beep(data_a[12]);

}
