#include <iostream>
#include <windows.h>
#include <string>
#include <vector>
extern void draw(void);
extern void data_tansform(char data[], int len);
class SerialPort {
private:
    HANDLE hSerial;
    bool connected;
    COMSTAT status;
    DWORD errors;

public:
    SerialPort(const char* portName) : connected(false), hSerial(INVALID_HANDLE_VALUE) {
        // �򿪴���
        hSerial = CreateFileA(portName,
            GENERIC_READ | GENERIC_WRITE,
            0,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            NULL);

        if (hSerial == INVALID_HANDLE_VALUE) {
            std::cerr << "Error opening serial port: " << portName << std::endl;
            return;
        }

        // ���ô��ڲ���
        DCB dcbSerialParams = { 0 };
        dcbSerialParams.DCBlength = sizeof(dcbSerialParams);

        if (!GetCommState(hSerial, &dcbSerialParams)) {
            std::cerr << "Error getting serial port state" << std::endl;
            CloseHandle(hSerial);
            return;
        }

        // ���ò�����115200, 8����λ, ��У��, 1ֹͣλ
        dcbSerialParams.BaudRate = CBR_115200;
        dcbSerialParams.ByteSize = 8;
        dcbSerialParams.StopBits = ONESTOPBIT;
        dcbSerialParams.Parity = NOPARITY;

        if (!SetCommState(hSerial, &dcbSerialParams)) {
            std::cerr << "Error setting serial port state" << std::endl;
            CloseHandle(hSerial);
            return;
        }

        // ���ó�ʱ
        COMMTIMEOUTS timeouts = { 0 };
        timeouts.ReadIntervalTimeout = 50;
        timeouts.ReadTotalTimeoutConstant = 50;
        timeouts.ReadTotalTimeoutMultiplier = 10;
        timeouts.WriteTotalTimeoutConstant = 50;
        timeouts.WriteTotalTimeoutMultiplier = 10;

        if (!SetCommTimeouts(hSerial, &timeouts)) {
            std::cerr << "Error setting timeouts" << std::endl;
            CloseHandle(hSerial);
            return;
        }

        connected = true;
        PurgeComm(hSerial, PURGE_RXCLEAR | PURGE_TXCLEAR);
        std::cout << "Connected to serial port: " << portName << std::endl;
    }

    ~SerialPort() {
        if (connected) {
            connected = false;
            CloseHandle(hSerial);
            std::cout << "Serial port closed" << std::endl;
        }
    }

    bool isConnected() {
        return connected;
    }

    int readData(char* buffer, unsigned int buf_size) {
        DWORD bytesRead;
        unsigned int toRead = 0;

        ClearCommError(hSerial, &errors, &status);
        if (status.cbInQue > 0) {
            toRead = (status.cbInQue < buf_size) ? status.cbInQue : buf_size;
        }

        if (toRead > 0) {
            if (!ReadFile(hSerial, buffer, toRead, &bytesRead, NULL)) {
                return -1;
            }
            return bytesRead;
        }

        return 0;
    }

    bool writeData(const char* buffer, unsigned int buf_size) {
        DWORD bytesSend;

        if (!WriteFile(hSerial, (void*)buffer, buf_size, &bytesSend, NULL)) {
            ClearCommError(hSerial, &errors, &status);
            return false;
        }
        return true;
    }
};



int main() {
    SerialPort serial("COM4"); // ����ʵ������޸�COM�˿ں�
    if (!serial.isConnected()) {
        std::cerr << "Failed to connect to serial port" << std::endl;
        return 1;
    }

    std::cout << "Serial communication ready. Type 'exit' to quit." << std::endl;

    char inputBuffer[256];
    char receiveBuffer[256];
    bool running = true;
    //����ͨ�Ż���
    inputBuffer[1] = '\0';
    inputBuffer[0] = 'Y';

    for (int i = 1;i <= 10;i++)
    {
        serial.writeData(inputBuffer, strlen(inputBuffer));
        Sleep(100);
    }
    std::cout << "���ڻ�����ϣ�" << std::endl;
    draw();//ͼ�ν����ʼ��
    while (running) {


        // �������ݲ���
        std::cout << "�Զ����������� " << std::endl;
		/* std::cin.getline(inputBuffer, sizeof(inputBuffer));//�ֶ��������ݷ���

         if (std::string(inputBuffer) == "exit") {
             running = false;
             continue;
         }*/
        inputBuffer[0] = 'Y';
        inputBuffer[0] = '\0';
        if (serial.writeData(inputBuffer, 1)) {
            std::cout << "Sent: " << inputBuffer << std::endl;
        }
        else {
            std::cerr << "Failed to send data" << std::endl;
        }

        // �������ݲ���
        int bytesRead = serial.readData(receiveBuffer, sizeof(receiveBuffer));
        std::cout << "Ԥ�ƽ���" << bytesRead << "�ֽ�" << std::endl;
        if (bytesRead > 0) {//�������ݴ�������
            receiveBuffer[bytesRead] = '\0'; // �����ַ�����ֹ��


			data_tansform(receiveBuffer, bytesRead);//�Խ��յ������ݽ��д�������ʾ��ͼ�ν�����

        }
        else if (bytesRead < 0) {
            std::cerr << "Error reading data" << std::endl;
        }
        // �����ӳ٣�����CPUռ�ù���
        Sleep(100);
    }
    return 0;
}
